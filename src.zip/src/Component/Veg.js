import React,{ Fragment,useEffect,useState } from "react";
import { Button,Container,Form,FormGroup, Input } from "reactstrap";
import fi from "../Component/images/veg1.jpg";
import pi from "../Component/images/veg2.jpg";
import bi from "../Component/images/veg1.jpg";

const Veg=()=>{
    useEffect(()=>{
        document.title="Veg Food || Food Delivery";
    },[]);
    return(
        <div>
             <Fragment>
            <h3>Food-Items</h3>
            
            <h5>Veg Kolhapuri</h5>
            <img src={fi} alt="" className="food" width="150px" height="100px"/>
            <p>Rs.130</p> 
            
            <Button type="submit" color="success" href="/cart1">Add to Cart</Button>
            <h5>Panner Kolhapuri</h5>
            <img src={pi} alt="" className="food" width="150px" height="100px"/>
            <p>Rs.180</p>
           
            <Button type="submit" color="success" href="/cart">Add to Cart</Button>
            <h5>Cheese Butter Masala</h5>
            <img src={bi} alt="" className="food" width="150px" height="100px"/>
            <p>Rs.120</p>
            
            <Button type="submit" color="success" href="/cart">Add to Cart</Button>
            
            </Fragment>
        </div>


    );
};
export default Veg;