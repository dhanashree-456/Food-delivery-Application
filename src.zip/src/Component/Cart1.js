import React, { useEffect, useState } from "react";
import { Button,Container,Form,FormGroup, Input } from "reactstrap";
import fi from "../Component/images/veg1.jpg";
import "./cart.css"
const Cart1=()=>{
    const[quantity,setQuantity]=useState(1);
    const handleDecrement =()=>{
        setQuantity(prevCount=>prevCount + 1);
      
    }
    const handleIncrement =()=>{
        setQuantity(prevCount=>prevCount - 1);
    }
    return(
        <div className="App">
            <table border={5}>
<thead>
          <tr>
<th>Image</th>            
<th>Product</th>
<th>Price</th>
<th>Quantity</th>
<th>Total Price</th>
</tr>
</thead>
<tbody>
<tr>
<td><img src={fi} alt="" className="food" width="100px" height="80px"/></td>    
<td>Veg Kolhapuri</td>
<td>130</td>
<td>
    <button type="button" onClick={handleDecrement} className="input-group-text">+</button>
    <div className="form-control text-center">{quantity}</div>
    <button type="button" onClick={handleIncrement} className="input-group-text">-</button>
</td>
<td>{130*quantity}</td>
</tr>

</tbody>
</table><br></br>
<Button type="submit" color="success" href="/Payment">Order</Button>
        </div>
    );
}
export default Cart1;