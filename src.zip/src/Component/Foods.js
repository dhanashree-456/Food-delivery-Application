import axios from "axios";
import React from "react";
import { toast } from "react-toastify";
import { Button, Card, CardBody, CardSubtitle, Container, CardText,CardTitle } from "reactstrap";
import base_url from "../api/bootapi";
const Foods=({food})=>{
   
     return (
        <Card className="text-center">
            <CardBody>
               <h4> <CardTitle className="font-weight-bold">{food.categoery}</CardTitle></h4>
                <h5><CardSubtitle>{food.title}</CardSubtitle></h5>
                <CardText>{food.description}</CardText>
               <h5> <CardText>{food.price}</CardText></h5>

                 <Container className="text-center">
                    
                 <Button type="submit" color="success" href="/cart">Add to Cart</Button>
                </Container> 
            </CardBody>
        </Card>
    );
};
export default Foods;