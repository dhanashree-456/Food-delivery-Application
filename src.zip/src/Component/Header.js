import React from "react";
import { Card,CardBody } from "reactstrap";
import "./header.css"

function Header({name,title}){
    return(
        <div className="headercss">
        <Card className="head_food">
            <CardBody className=" bg-warning" >
                <h1 className="text-center my-2">THE FOODIE EXPRESS</h1>
            </CardBody>
        </Card>
        </div>
    );

}
export default Header;