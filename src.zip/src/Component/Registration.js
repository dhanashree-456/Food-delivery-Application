import React, { Fragment, useEffect, useState } from "react";
import { ToastContainer, toast } from 'react-toastify';
import { Button,Input,alert } from "reactstrap";

const Registration = () => {
   const [formData, setFormData] = useState({
        id:"",
        name: "",
        email: "",
        password: "",
        reenterPassword: ""
    })
    const [errors, setErrors] = useState({});
    const {id, name, email, password,reenterPassword } = formData
    useEffect(() => {
    validateForm();
  }, [formData]);

    const onChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value })
    }

    const onSubmit = async (e) => {
        e.preventDefault();
        console.log(errors)

        const isValid = validateForm();
        console.log(isValid)
        if (isValid) {
            try {
                const response = await fetch("http://localhost:7075/user", {
                    method: 'post',
                    body: JSON.stringify({id,name,email,password,reenterPassword}),
                    headers: {
                        'Content-Type': 'application/json' 
                    }
                })
                const data = await response.json();
                console.log(data)
                if (data.error) {
                    setErrors({ ...errors, server: data.error });
                } else {
                   // alert("Register succesfull")
                    console.log("success")
                    toast.success("Register successfully",{position:"top-center"});
                }
            } catch (err) {
                setErrors({ ...errors, server: err.message })
            }
        }
    }

    const validateForm = () => {
        let formErrors = {}
         if (!id) {
            formErrors.id = "Id is required"
        }
        if (!name) {
            formErrors.name = "Name is required"
        }
        
        if (!email) {
            formErrors.email = "email is required"
        }
      
        if (!password) {
            formErrors.password = "password is required"
        }
           if(password.length < 8){
             formErrors.password = "password should have at least 8 numbers"
         }
        //    if(password > 9){
        //     formErrors.password = "password cannot exceed more than 8 characters"
        //  }
         if (!reenterPassword) {
            formErrors.reenterPassword = "Re-enter password is required"
        }
        if(password!= reenterPassword){
            formErrors.reenterPassword="Password not match"
        }

        setErrors(formErrors);
        return Object.keys(formErrors).length === 0
    }
   
    return (
        <>
            <h2>Registration</h2>
            <form onSubmit={onSubmit}>
            <label htmlFor="id">Id</label>
                <Input
                    type="text"
                    placeholder="Enter Id"
                   
                    name="id"
                    value={id}
                    onChange={onChange}
                       
                />
              {errors.id && <p style={{color:"red"}}>{errors.id}</p>} 
                <label htmlFor="name">Name</label>
                <Input
                    type="text"
                   
                    name="name"
                    value={name}
                    id="name"
                    placeholder="Enter  Name"
                    onChange={onChange}
                />
               {errors.name && <p style={{color:"red"}}>{errors.name}</p>}
                <label htmlFor="Email">Email</label>
                <Input
                    type="text"
                    name="email"
                    value={email}
                    placeholder="Email Address"
                    onChange={onChange}
                />
               {errors.email && <p style={{color:"red"}}>{errors.email}</p>}
                <label htmlFor="Password">Password</label>
                <Input
                    type="password"
                    name="password"
                    value={password}
                    placeholder="Enter Passsword"
                    onChange={onChange}
                />
                
                 {errors.password && <p style={{color:"red"}}>{errors.password}</p>}
                 <label htmlFor="reenterPassword">Re-enter Password</label>
                <Input
                    type="password"
                    name="reenterPassword"
                    value={reenterPassword}
                    placeholder="Re-Enter Passsword"
                    onChange={onChange}
                />
                {errors.reenterPassword && <p style={{color:"red"}}>{errors.reenterPassword}</p>}

                {errors.server && <p style={{color:"red"}}>{errors.server}</p>}
                <Button type="submit" color="success"  >Register</Button>{' '}
                <Button type="submit" color="success" href="/user-login">Login</Button>
            </form>
        </>
    );
};



export default Registration;